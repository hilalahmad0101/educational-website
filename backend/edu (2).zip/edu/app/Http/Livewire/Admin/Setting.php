<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class Setting extends Component
{
    public function render()
    {
        return view('livewire.admin.setting')->layout('layout.admin-app');
    }
}
