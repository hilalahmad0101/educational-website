<li><a class="dropdown-item" href="#" wire:click.prevent='logout'>Logout</a></li>
<?php /**PATH F:\projects\edu\backend\edu\resources\views/livewire/admin/auth/logout.blade.php ENDPATH**/ ?>