<div>
     <?php $__env->slot('title', null, []); ?> Contact US <?php $__env->endSlot(); ?>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="main__page">
            <i class="fa-solid fa-house-user"></i> <span> > Enquerie</span>
        </div>

        <div class="main__page__content">
            <div class="main__heading">
                <div class="main__left">
                    <h1 class="main__left__h1">Enquerie</h1>
                    <p class="main__left__p">Here will be show some user request.</p>
                </div>
            </div>
            <div class="main__page__form">
                <div class="table-responsive w-100">
                    <table class="table">
                        <tbody style="vertical-align: middle">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Name</td>
                                    <td>Email</td>
                                    <td>Phone number</td>
                                    <td>Preffered course</td>
                                    <td>Action</td>
                                </tr>
                            </thead>
                            <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <p><?php echo e($contact->id); ?></p>
                                    </td>
                                    <td>
                                        <p><?php echo e($contact->name); ?></p>
                                    </td>
                                    <td>
                                        <p><?php echo e($contact->email); ?></p>
                                    </td>
                                    <td>
                                        <p>+9839843993</p>
                                    </td>
                                    <td>
                                        <p><?php echo e($contact->p_course); ?></p>
                                    </td>
                                    <td class="d-flex align-content-center">
                                        <p class="action1"><i class="fa-solid fa-check"></i></p>
                                        <p class="action2"><i class="fa-solid fa-trash"></i></p>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h1>Record not found</h1>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<?php /**PATH F:\projects\edu\backend\edu\resources\views/livewire/admin/contact-us.blade.php ENDPATH**/ ?>