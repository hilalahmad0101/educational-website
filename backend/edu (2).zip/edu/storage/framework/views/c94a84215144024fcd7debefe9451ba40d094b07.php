<div>
     <?php $__env->slot('title', null, []); ?> Change Password <?php $__env->endSlot(); ?>
    <div class="container">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('error')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="main__page">
            <i class="fa-solid fa-house-user"></i> <span> > Profile</span>
        </div>
        <div class="main__page__content">
            <div class="main__page__form">
                <div class="main__page__form__right">
                    <form wire:submit.prevent='update'>
                        <div class="main__page__section2">
                            <h1 class="main__page__form__right__h1">
                                Change Password
                            </h1>
                            <div class="main__page__form__cont">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="my-2">
                                            <label for="">
                                                <h3>Username</h3>
                                            </label>
                                            <input type="text" wire:model.lazy="username" id="form__control"
                                                placeholder="Enter your Username">
                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="my-2">
                                            <label for="">
                                                <h3>New Password</h3>
                                            </label>
                                            <input type="password" wire:model.lazy="new_password" id="form__control"
                                                placeholder="Enter your new Password">
                                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="main__btns">
                            <button type="submit" class="main__page__form__image__btn__next">Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\projects\edu\backend\edu\resources\views/livewire/admin/change-password.blade.php ENDPATH**/ ?>