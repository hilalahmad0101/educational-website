<li><a class="dropdown-item" href="#" wire:click.prevent='logout'>Logout</a></li>
